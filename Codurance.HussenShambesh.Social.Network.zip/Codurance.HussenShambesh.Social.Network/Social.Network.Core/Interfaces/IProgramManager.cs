﻿namespace Social.Network.Core.Interfaces
{
	public interface IProgramManager
	{
		/// <summary>
		/// method to start the main console application
		/// </summary>
		void Start();
	}
}