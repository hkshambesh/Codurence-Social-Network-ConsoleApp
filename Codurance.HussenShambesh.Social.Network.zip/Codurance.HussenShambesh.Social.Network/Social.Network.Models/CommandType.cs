﻿namespace Social.Network.Models
{
	public enum CommandType
	{
		Unknown = 0,
		Post,
		Read,
		Follow,
		Wall
	}
}