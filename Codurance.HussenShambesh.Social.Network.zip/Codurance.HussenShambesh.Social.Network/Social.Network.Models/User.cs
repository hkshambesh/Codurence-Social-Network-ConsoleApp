﻿namespace Social.Network.Models
{
	using System;

	public class User
	{
		public Guid UserId { get; set; }
		public string Username { get; set; }
	}
}